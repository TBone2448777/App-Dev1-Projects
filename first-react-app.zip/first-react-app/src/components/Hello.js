import React from 'react';
import styles from './Hello.component.css';

function Hello(){
    return(
        <h1 className="helloText">Hello World</h1>
    )
}

export default Hello;